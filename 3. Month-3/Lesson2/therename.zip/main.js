function $ (sel) {
  return document.querySelector(sel)
}
// let arr = [3,3,3]

// let le = arr.length
// function there (a , b){
//     if(le === 0){
//         return false
//     }else {
//      return a.every((vall )=> vall===b )}
// }

// console.log(there(arr , 3));
// let wer = null
//  $("#form").addEventListener("submit",(e)=>{
//     e.preventDefault()
//     arr.push($("#searchName").value)
//     wer = arr.every((vall )=> vall===$("#Name").value )
//  })
//  console.log(wer);

const arr = []
let text = ' '

$('#form').addEventListener('submit', e => {
  e.preventDefault()
  arr.push($('#searchName').value.split(' '))
  let searchName = $('#Name').value
  console.log(searchName) 
  if(arr[0].includes(searchName,0)){
    text ="Qidiruvdagi ism oldin kiritilgan";
  }else{
    arr[0].push(searchName)
    text = 'ism yuq ekan endi qoshildi'
  }
  $(".text").textContent = text
})
console.log(arr);
// var son = [3.02 , -3.02 , 2 , -3.65    ]

// function yaxlit(son){
//     for (i of son){
//        if(i<0){
//         console.log(Math.round( i * -1 ));
//        }else{
//         console.log(Math.round( i  ));
//        }
//     }
// }
// yaxlit(son)
