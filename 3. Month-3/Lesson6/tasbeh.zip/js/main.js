// function add(a , b){
//     alert(a + b)
// }
// // function multiply(a , b){
// //     return a * b
// // }
// function devide(a , b){
//     alert(a / b)
// }
// // function ayiruv(a , b){
// //     return a - b
// // }


// let bson = prompt("b") -0
// let ason = prompt("a") -0
// devide(bson ,ason )




let text = document.querySelector("#heading")
// zikrtext = document.querySelector("#zikr")

let num = 0
let zikr = "start"
var zikrtext = document.getElementById("#zikr")
// zikrtext.textContent = incrase()

function incrase(){
  text.textContent =  num ++
  if(num <= 33){
    zikrtext.textContent = "SubhanAlloh"
  }else if ( num<=66 ){
      zikrtext.textContent = "Alhamdulillah"
  
  }else if (num <= 99){
      zikrtext.textContent = "Allohu Akbar"
  }else{
    document.location.reload()
  }
}

function reset(){
    document.location.reload()
}
function decrase(){
    text.textContent = num --
}





// /////////////////////////////////////
// for (i=1 ;i<100 ; i++){
//   console.log(i)
// }
// for (x=1 ; x<100 ; x++){
//   if(x % 2 == 0){
//     console.log(x)
//   }
// }
// for (f=100 ; f>0 ; f--){
//   if(f % 2 == 0){
//     console.log(f)
//   }
// }
// for (y=1 ; y<100 ; y++){
//   if(y % 2 == 1){
//     console.log(y)
//   }
// }

