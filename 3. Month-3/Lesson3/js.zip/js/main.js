

function dtm(ball){
    if (ball < 60 ){
       text = "Siz normativ ball ham olomapsiz"
    }
    else if(ball <=101  ){
        text = 'Siz super asosida qabul qilindingiz'
    }
    else if (ball <=170  ){
        text ='Siz kontrakt asosida qabul qilindingiz'
    }
    else if (ball <=189 ){
        text = "Siz grand asosida oqishga qabul qilindingiz"
    }
    else{
       text = "Siz notugri malumot kiritdingiz"
    }
    const headingEl = document.querySelector("#heading")
    headingEl.textContent = text
    }


let  ball = prompt('balingizni yozing')
ball = dtm(ball)







// // function kalku(a, amal ,c){
// //     // let a = prompt("A sonni kiriting")
// //     // let b = prompt("B sonni kiriting")
// //     // let amal = prompt("amalni kiriting")
// //     let result = a + amal + c
// //     console.log(result)
// // }

// // // let a = prompt("A sonni kiriting")
// // // let c = prompt("B sonni kiriting")
// // // let amal = prompt("amalni kiriting")
// // kalku(1 ,2 
// //     )
// function squad (a , b){
//    alert(a**b)
// }
// let a = prompt("a son")
// let b = prompt("b son")
// squad(a , b)